#version 150

uniform sampler2D InSampler;

in vec2 texCoord;

out vec4 fragColor;

const vec3 LumaWeights = vec3(0.299, 0.587, 0.114);

void main() {
    vec4 baseColor = texture(InSampler, texCoord);

    // 1. 75% Desaturation (25% color remaining, 75% cold stormy luminance)
    float luma = dot(baseColor.rgb, LumaWeights);
    vec3 stormLuma = vec3(luma * 0.94, luma * 0.98, luma * 1.06);
    vec3 desat = mix(stormLuma, baseColor.rgb, 0.25);

    // 2. Smooth cinematic storm vignette (darkens edges smoothly without blinding center)
    vec2 uv = texCoord - 0.5;
    float dist = length(uv);
    float vignette = smoothstep(0.85, 0.30, dist);

    // Edge shading with dark oceanic tempest undertone
    vec3 edgeDarkening = vec3(0.50, 0.56, 0.65);
    vec3 vigColor = mix(desat * edgeDarkening, desat, vignette);
    float vigFactor = 0.45 + 0.55 * vignette;

    vec3 finalColor = vigColor * vigFactor;

    fragColor = vec4(clamp(finalColor, 0.0, 1.0), baseColor.a);
}
