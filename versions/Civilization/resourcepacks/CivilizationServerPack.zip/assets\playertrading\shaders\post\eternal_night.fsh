#version 150

uniform sampler2D InSampler;

in vec2 texCoord;

out vec4 fragColor;

const vec3 LumaWeights = vec3(0.299, 0.587, 0.114);

void main() {
    vec4 baseColor = texture(InSampler, texCoord);

    // 1. 75% desaturation (25% color, 75% grayscale for a haunting drained look)
    float luma = dot(baseColor.rgb, LumaWeights);
    vec3 desat = mix(vec3(luma), baseColor.rgb, 0.25);

    // 2. Smooth cinematic vignette (darkens edges into the void without blinding center)
    vec2 uv = texCoord - 0.5;
    float dist = length(uv);
    float vignette = smoothstep(0.85, 0.30, dist);
    vec3 finalColor = desat * (0.45 + 0.55 * vignette);

    fragColor = vec4(clamp(finalColor, 0.0, 1.0), baseColor.a);
}
