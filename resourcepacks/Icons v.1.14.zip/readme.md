# **Terms of use**

###### 

###### **You can:**

* ✅ Use Icons in Modpacks
* ✅ Use Icons for Content Creation (preferrably with attribution/link)*
* ✅ Use Icons as reference to create something on your own**
* ✅ Edit Icons for personal use
* ✅ Create Addons, Extensions and anything similiar

*Pages that can be linked back to include CurseForge, Modrinth or Planet Minecraft

**Referenced assets should be completely your own



###### **You cannot:**

* ❌ Redistribute edited or unedited assets without permission
* ❌ Re-upload Icons
* ❌ Claim ownership of Icons' assets


These terms may be changed as we deem necessary and at any time.

Versions of this pack before 1.9.2 make use of NegativeSpaces4 resource pack by AmberW/AmberWat which is under Creative Commons Attribution 4.0 International terms.

###### 

###### **Credits:**

* mr\_ch0c0late (Creator and Idea)
* Zartrix (PackDev)
* Moggla (Creator of MC Language Formatter)
* KikuGie (Creator of our Edited Respackopts config)


###### **Former Translation Contributions:**

* Leroidesafk (French, Romanian, Portuguese(BR), Italian)
* Agente\_511 (Portuguese(PT))
* Magnogen (English(GB))
* Blazemetal\_VN (Vietnamese)
* Victorth (Finding and fixing bugs in Portuguese(BR))